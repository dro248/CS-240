package shared.communication;

public class ProjectParams extends UserParams
{
	public ProjectParams(String _username, String _password) 
	{
		super(_username, _password);
	}
}
